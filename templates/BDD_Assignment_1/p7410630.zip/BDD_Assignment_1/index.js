const app = require('./controller/app');

app.listen(80, () => {
  console.log('MVC Server Started');
})